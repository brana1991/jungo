$('.thankyou-page').on('click', function() {
	window.location.reload(true);
});
